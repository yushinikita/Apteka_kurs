﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace apteka
{
    public class YourViewModel
    {
        public string foto { get; set; }

        public Uri FotoUri => string.IsNullOrEmpty(foto) ? null : new Uri(foto, UriKind.Absolute);
    }
}
