﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace apteka
{
    /// <summary>
    /// Логика взаимодействия для polzovatel.xaml
    /// </summary>
    public partial class polzovatel : Page
    {
        public polzovatel()
        {
            InitializeComponent();
            Update();
            poisk();
        }
        private void Update() 
        {
            var films = App.Context.tovar_apt.ToList(); 
            LViewFilmy.ItemsSource = films;
           

        }

        private void korzina_Click(object sender, RoutedEventArgs e)
        {
            var tovar = (sender as Button).DataContext as tovar_apt;
            if (tovar != null) 
            {
                oformlenie myPage = new oformlenie(tovar);
                this.NavigationService.Navigate(myPage);
                
            }
            else
            {
                MessageBox.Show("Ошибка: товар не найден."); // Notify if null
            }

        }

        private void spisok_Click(object sender, RoutedEventArgs e)
        {

            NavigationService.Navigate(new pozovatel_zakaz());
        }

        private void vihod_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new avtoriz());
        }
        private void poisk()
        {
            var products = App.Context.tovar_apt.ToList();
            products = products.Where(p => p.nazvanie.ToLower().Contains(text1.Text.ToLower())).ToList();

           



            LViewFilmy.ItemsSource = products;
            
        }

        private void text1_TextChanged(object sender, TextChangedEventArgs e)
        {
            poisk();
        }
    }
   
}
