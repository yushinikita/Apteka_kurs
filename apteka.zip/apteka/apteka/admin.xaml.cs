﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace apteka
{
    /// <summary>
    /// Логика взаимодействия для admin.xaml
    /// </summary>
    public partial class admin : Page
    {
        public admin()
        {
            InitializeComponent();
            Update();
            poisk();
        }
        private void Update()
        {
            var films = App.Context.tovar_apt.ToList();
            LViewFilmy.ItemsSource = films;


        }
        private void obnovlenie_Click(object sender, RoutedEventArgs e)
        {
            var tovar = (sender as Button).DataContext as tovar_apt;
            if (tovar != null)
            {
                dobavlenie_obnovlenie myPage = new dobavlenie_obnovlenie(tovar);
                this.NavigationService.Navigate(myPage);

            }
            else
            {
                MessageBox.Show("Ошибка: товар не найден."); // Notify if null
            }
        }

        private void vihod_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new avtoriz());
        }

        private void spisok_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new dobavlenie_tovar());
        }

        private void zakaz_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new zakaz());
        }

        private void pukt_Click(object sender, RoutedEventArgs e)
        {

        }

        private void delet_Click(object sender, RoutedEventArgs e)
        {
            var currentService = (sender as Button).DataContext as tovar_apt; //Создание переменной выбранного сервиса

            if (MessageBox.Show($"Вы уверены, что хотите удалить товар? " +
                $"{currentService.articl}?", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
            //Если во всплывающем окне вы согласились удалить услугу
            {
                App.Context.tovar_apt.Remove(currentService); //Удалить выбранный сервис
                App.Context.SaveChanges();//Сохранить изменения в базе
                var services = App.Context.tovar_apt.ToList();
                LViewFilmy.ItemsSource = services; //Заполнение обновленным списком сервисов

            }
        }
        private void poisk()
        {
            var products = App.Context.tovar_apt.ToList();
            products = products.Where(p => p.nazvanie.ToLower().Contains(text1.Text.ToLower())).ToList();





            LViewFilmy.ItemsSource = products;

        }

        private void text1_TextChanged(object sender, TextChangedEventArgs e)
        {
            poisk();
        }
    }
}
