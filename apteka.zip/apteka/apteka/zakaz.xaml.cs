﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace apteka
{
    /// <summary>
    /// Interaction logic for zakaz.xaml
    /// </summary>
    public partial class zakaz : Page
    {
        public List<status_zakaza_apt> naimenovanie123 { get; set; } = App.Context.status_zakaza_apt.ToList(); //Создание переменной со списком стран для ComboBox
       
        public zakaz()
        {
            InitializeComponent();
            Update();
            this.DataContext = this;
        }
        private void Update()
        {
            var _user = App.Context.zakaz_apt.ToList();
            lview.ItemsSource = _user;
        }

        private void nazad_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new admin());
        }

        private void status1_Click(object sender, RoutedEventArgs e)
        {
            var tovar = (sender as Button).DataContext as zakaz_apt;
            var stranas = App.Context.status_zakaza_apt.ToList(); //Переменная со списком стран
            
            var strana = naimenovanie456.SelectedItem as status_zakaza_apt; //Переменная с выбранным элементом списка стран
            var stranaNazv = $"{strana.naimenovanie}"; //Переменная с названием страны (берем по предыдущей переменной)
            var stranaId = stranas.Where(x => x.naimenovanie == stranaNazv).FirstOrDefault().id_status; //Переменная с кодом страны, которая имеет название предыдущей переменной

            tovar.status_zakaza = stranaId;
            

            App.Context.SaveChanges(); //Сохранить изменения в контексте
            MessageBox.Show("Заказ успешно обновлен", "Уведомление",
                    MessageBoxButton.OK, MessageBoxImage.Information);//Уведомление о добавлении
            Update();
        }
    }
}
