﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.WebRequestMethods;
using System.IO;

namespace apteka
{
    /// <summary>
    /// Interaction logic for dobavlenie_tovar.xaml
    /// </summary>
    public partial class dobavlenie_tovar : Page
    {
        private byte[] _mainImageData;
        public List<proizvoditel_apt> nazvanie1 { get; set; } = App.Context.proizvoditel_apt.ToList(); //Создание переменной со списком стран для ComboBox
        public List<forma_vipuska_apt> naimenovanie1 { get; set; } = App.Context.forma_vipuska_apt.ToList(); //Создание переменной со жанров для ComboBox
        public List<status_recept_apt> naimenovanie_status1 { get; set; } = App.Context.status_recept_apt.ToList(); //Создание переменной со жанров для ComboBox
        public dobavlenie_tovar()
        {
            InitializeComponent();
            DataContext = this;
        }

        private void BtnVybratFoto_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image |*.png; *.jpg; *.jpeg"; //Открываем проводник и ищем в папках изображения в форматах *.png; *.jpg; *.jpeg
            if (ofd.ShowDialog() == true)
            {
                _mainImageData = System.IO.File.ReadAllBytes(ofd.FileName);
                ImgFilm.Source = (ImageSource)new ImageSourceConverter().ConvertFrom(_mainImageData); //Перенос выбранного на форму
            }
        }

        private void BtnSohranitFilm_Click(object sender, RoutedEventArgs e)
        {
            var stranas = App.Context.proizvoditel_apt.ToList(); //Переменная со списком стран
            var strana = nazvanie2.SelectedItem as proizvoditel_apt; //Переменная с выбранным элементом списка стран
            var stranaNazv = $"{strana.nazvanie}"; //Переменная с названием страны (берем по предыдущей переменной)
            var stranaId = stranas.Where(x => x.nazvanie == stranaNazv).FirstOrDefault().id_proizvoditel; //Переменная с кодом страны, которая имеет название предыдущей переменной

            var zhanrs = App.Context.forma_vipuska_apt.ToList();//Переменная со списком жанров
            var zhanr = naimenovanie2.SelectedItem as forma_vipuska_apt; //Переменная с выбранным элементом списка жанров
            var zhanrNazv = $"{zhanr.naimenovanie}";//Переменная с названием жанра (берем по предыдущей переменной)
            var zhanrId = zhanrs.Where(x => x.naimenovanie == zhanrNazv).FirstOrDefault().id_forma; //Переменная с кодом жанра, который имеет название предыдущей переменной

            var status = App.Context.status_recept_apt.ToList();//Переменная со списком жанров
            var statush = naimenovanie_status2.SelectedItem as status_recept_apt; //Переменная с выбранным элементом списка жанров
            var stat = $"{statush.naimenovanie_status}";//Переменная с названием жанра (берем по предыдущей переменной)
            var statusid = status.Where(x => x.naimenovanie_status == stat).FirstOrDefault().id_status; //Переменная с кодом жанра, который имеет название предыдущей переменной

            var tovar = new tovar_apt {
                articl = Int32.Parse(TbKod.Text),
            nazvanie = TbNazvanie.Text,
            sroc_godnosti = TbGodVypuska.SelectedDate,
            cena = Int32.Parse(TbProdolzh.Text),
           sostav = TbOpisanie.Text,
            kolichestvo_sclad = Int32.Parse(TbVozrast.Text),
            proizvoditel = stranaId,
            form_vipusk = zhanrId,
            status_recept = statusid,
            foto = _mainImageData,
        };

            App.Context.tovar_apt.Add(tovar);
            App.Context.SaveChanges(); //Сохранить изменения в контексте
            MessageBox.Show("Товар успешно добавлен", "Уведомление",
                    MessageBoxButton.OK, MessageBoxImage.Information);//Уведомление о добавлении
        }

        private void BtnNazad_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new admin());
        }
    }
}
