﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace apteka
{
    /// <summary>
    /// Логика взаимодействия для pozovatel_zakaz.xaml
    /// </summary>
    public partial class pozovatel_zakaz : Page
    {
        public pozovatel_zakaz()
        {
            InitializeComponent();
            Update();
        }
        private void Update()
        {
            int currentUserId = App.User.id_klient;/* Get the current user's ID */;

            // Fetch all orders and filter by the current user's ID
            var filteredOrders = App.Context.zakaz_apt
                .Where(order => order.klient == currentUserId) // Adjust this line based on your data structure
                .ToList();

            // Bind the filtered orders to the ListView
            lview.ItemsSource = filteredOrders;
        }

        private void nazad_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new polzovatel());

        }

        private void status1_Click(object sender, RoutedEventArgs e)
        {
            var tovar = (sender as Button).DataContext as zakaz_apt;

            if (tovar.status_zakaza == 1)
            {
                // Show confirmation dialog
                var result = MessageBox.Show("Вы уверены, что хотите отменить заказ?",
                                               "Подтверждение отмены",
                                               MessageBoxButton.YesNo,
                                               MessageBoxImage.Warning);

                // Check the user's response
                if (result == MessageBoxResult.Yes)
                {
                   
                    tovar.status_zakaza = 3;                              
                    App.Context.SaveChanges(); 
                    MessageBox.Show("Заказ успешно отменен", "Уведомление",
                                    MessageBoxButton.OK, MessageBoxImage.Information); // Notification of cancellation
                    Update();
                }
                else
                {
                    // User chose not to cancel
                    MessageBox.Show("Отмена заказа отменена", "Информация",
                                    MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Заказ нельзя отменить");
            }
        }
    }
}
