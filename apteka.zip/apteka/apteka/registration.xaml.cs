﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace apteka
{
    /// <summary>
    /// Логика взаимодействия для registration.xaml
    /// </summary>
    public partial class registration : Page
    {
        public registration()
        {
            InitializeComponent();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               
                var user = new user_apt
                {
                    familia = familia.Text,
                    imy = imy.Text,
                    otchestvo = otche.Text,
                    email = email.Text,
                    login = login.Text,
                    parol = parol.Text,
                    phone = phone.Text,
                    data_rojdenia = data.SelectedDate.Value,
                    role = 1



                };
                App.Context.user_apt.Add(user);
                App.Context.SaveChanges();
                MessageBox.Show("регистрация успешно пройдена");
            }
            catch
            {
                MessageBox.Show("error");
            }
        }

        private void Bntoff_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new avtoriz());
        }
    }
}
