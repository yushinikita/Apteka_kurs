﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace apteka
{
    /// <summary>
    /// Логика взаимодействия для oformlenie.xaml
    /// </summary>
    public partial class oformlenie : Page
    {

        private tovar_apt _tovar;
        private byte[] _mainImageData;
        public List<punkt_vidacha_apt> adres1 { get; set; } = App.Context.punkt_vidacha_apt.ToList();
        public List<metod_oplata_apt> naimenovanie1 { get; set; } = App.Context.metod_oplata_apt.ToList();

        public oformlenie(tovar_apt Tovar)
        {
            InitializeComponent();
            DataContext = this;
            _tovar = Tovar;
            if (_tovar.foto != null)
            {
                image1.Source = (ImageSource)new ImageSourceConverter().ConvertFrom(_tovar.foto); //Помещаем постер выбранного фильма
            }

            Update();
        }

        private void Update()
        {
            
            
            ofor.Text = "Оформление заказа: " + _tovar.nazvanie;
            cena123.Text = "Стоимость: " + _tovar.cena;
           
           

        }

        private void dobav_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DateTime today = DateTime.Today;
                var role_ = App.Context.punkt_vidacha_apt.ToList();
                var status_ = App.Context.metod_oplata_apt.ToList();

                var role1 = adress.SelectedItem as punkt_vidacha_apt;
                var status1 = role.SelectedItem as metod_oplata_apt;

                var rolenaz = $"{role1.adres}";
                var statusnaz = $"{status1.naimenovanie}";

                var roleid = role_.Where(x => x.adres == rolenaz).FirstOrDefault().id_punkt;
                var statusid = status_.Where(x => x.naimenovanie == statusnaz).FirstOrDefault().id_metod;

                var users = new zakaz_apt
                {
                    spisok_tovarov = _tovar.articl,
                    klient = App.User.id_klient,
                    data_zakaza = today,
                    status_zakaza = 1,
                    punkt_vidahi = roleid,
                    metod_oplata = statusid,
                    kolic = Int32.Parse(kolich.Text)


                };
                App.Context.zakaz_apt.Add(users);
                App.Context.SaveChanges();
                MessageBox.Show("Заказ успешно оформлен");
            }
            catch
            {
                MessageBox.Show("Заполните все поля");
            }
        }

        private void nazad_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new polzovatel());
        }
    }
}
