﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace apteka
{
    /// <summary>
    /// Логика взаимодействия для avtoriz.xaml
    /// </summary>
    public partial class avtoriz : Page
    {
        public avtoriz()
        {
            InitializeComponent();
        }

        private void btn1_avtoriz_Click(object sender, RoutedEventArgs e)
        {
            var _user = App.Context.user_apt.FirstOrDefault(p => p.login == login.Text && p.parol == parol.Password);
            if (_user != null)
            {
                if (_user.role == 1)
                {
                    App.User = _user;
                    NavigationService.Navigate(new polzovatel());
                }
                if (_user.role == 2)
                {
                    App.User = _user;
                    NavigationService.Navigate(new admin());

                }
                
            }
            else
            {
                MessageBox.Show("неверный логин или пароль");
            }
        }

        private void btn1_registation_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new registration());
        }
    }
}
